package cs_assignment_2;

public class Main {

	public static void main(String[] args) {
		Runner runner = new Runner();
		runner.start();
	}

}
